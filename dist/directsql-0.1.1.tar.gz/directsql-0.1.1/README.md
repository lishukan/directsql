# directsql
一个简单的使用python操作mysql的工具，提供了一些类似sql语法的方法，最终拼接成sql。可以很好地处理一些常见场景，不依赖orm 的同时避免手写大量sql。A simple tool using Python to operate MySQL provides some methods similar to SQL syntax, and finally splices into SQL. It can handle some common scenarios very well, and avoid writing a lot of SQL without relying on ORM.
